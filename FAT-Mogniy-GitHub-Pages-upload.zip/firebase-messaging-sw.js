/* Firebase Cloud Messaging service worker for FAT Mogniy. */
importScripts('https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.23.0/firebase-messaging-compat.js');
firebase.initializeApp({
  apiKey: "AIzaSyCeIBjbXnKdLq6oGNr12vCB53oNpXv1LYM",
  authDomain: "fa-mogniy.firebaseapp.com",
  databaseURL: "https://fa-mogniy-default-rtdb.firebaseio.com/",
  projectId: "fa-mogniy",
  storageBucket: "fa-mogniy.firebasestorage.app",
  messagingSenderId: "676431734491",
  appId: "1:676431734491:web:a49fc5748999aabe774efe",
  measurementId: "G-19F9M7Z005"
});
const messaging = firebase.messaging();
messaging.onBackgroundMessage(payload => {
  const d = payload.data || {};
  const title = d.title || d.senderName || 'FAT Mogniy';
  const options = {
    body: d.body || 'Новое сообщение',
    icon: '/favicon.ico',
    badge: '/favicon.ico',
    tag: d.tag || ('fat-mogniy-' + (d.targetId || 'message')),
    renotify: true,
    data: { link: d.link || 'https://cool-moxie-9b057a.netlify.app/' }
  };
  return self.registration.showNotification(title, options);
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  const target = event.notification.data && event.notification.data.link || 'https://cool-moxie-9b057a.netlify.app/';
  event.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(list => {
    for (const client of list) { if ('focus' in client) { client.navigate(target); return client.focus(); } }
    return clients.openWindow(target);
  }));
});
