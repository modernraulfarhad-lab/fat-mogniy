const { onValueCreated } = require('firebase-functions/v2/database');
const { initializeApp } = require('firebase-admin/app');
const { getDatabase } = require('firebase-admin/database');
const { getMessaging } = require('firebase-admin/messaging');
initializeApp();

async function sendToUser(uid, payload) {
  const db = getDatabase();
  const profileSnap = await db.ref(`users/${uid}`).get();
  const profile = profileSnap.val() || {};
  if (profile.notificationsEnabled !== true) return;
  const tokenSnap = await db.ref(`users/${uid}/fcmTokens`).get();
  const tokenMap = tokenSnap.val() || {};
  const tokens = [...new Set(Object.values(tokenMap).filter(v => typeof v === 'string' && v.length > 20))];
  if (!tokens.length) return;
  const result = await getMessaging().sendEachForMulticast({
    tokens,
    data: Object.fromEntries(Object.entries(payload).map(([k,v]) => [k, String(v ?? '')])),
    webpush: { headers: { Urgency: 'high', TTL: '86400' }, fcmOptions: { link: 'https://cool-moxie-9b057a.netlify.app/' } }
  });
  // Remove expired/unregistered tokens so they won't be retried forever.
  const updates = {};
  result.responses.forEach((r, i) => {
    if (!r.success && ['messaging/registration-token-not-registered','messaging/invalid-registration-token'].includes(r.error && r.error.code)) {
      for (const [key, value] of Object.entries(tokenMap)) if (value === tokens[i]) updates[`users/${uid}/fcmTokens/${key}`] = null;
    }
  });
  if (Object.keys(updates).length) await db.ref().update(updates);
}

exports.pushDirectMessages = onValueCreated('chats/{uidA}/{uidB}/messages/{messageId}', async event => {
  const m = event.data.val() || {};
  if (!m.text || !m.sender) return;
  const { uidA, uidB } = event.params;
  const recipient = m.sender === uidA ? uidB : uidA;
  const profile = (await getDatabase().ref(`users/${m.sender}`).get()).val() || {};
  const senderName = m.senderName || profile.username || 'Новое сообщение';
  await sendToUser(recipient, {
    type: 'chat', title: senderName, senderName,
    body: String(m.text).slice(0, 180), targetId: [uidA, uidB].sort().join('_'),
    link: 'https://cool-moxie-9b057a.netlify.app/'
  });
});

exports.pushGroupMessages = onValueCreated('groupChats/{groupId}/messages/{messageId}', async event => {
  const m = event.data.val() || {};
  if (!m.text || !m.sender) return;
  const db = getDatabase();
  const group = (await db.ref(`groups/${event.params.groupId}`).get()).val() || {};
  const senderProfile = (await db.ref(`users/${m.sender}`).get()).val() || {};
  const senderName = m.senderName || senderProfile.username || 'Участник';
  const members = group.members || {};
  const recipients = Object.keys(members).filter(uid => members[uid] === true && uid !== m.sender);
  await Promise.all(recipients.map(uid => sendToUser(uid, {
    type: 'group', title: `${group.name || 'Группа'} · ${senderName}`,
    senderName, groupName: group.name || 'Группа', body: String(m.text).slice(0, 180),
    targetId: event.params.groupId, link: 'https://cool-moxie-9b057a.netlify.app/'
  })));
});
